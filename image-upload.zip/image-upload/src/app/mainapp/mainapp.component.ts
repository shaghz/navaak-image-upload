import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainapp',
  templateUrl: './mainapp.component.html'
})
export class MainappComponent implements OnInit {

  constructor() { 
    
      }
    
      ngOnInit() {
      }
    

}
