var map = {

    'dropzone': 'node_modules/dropzone'
};